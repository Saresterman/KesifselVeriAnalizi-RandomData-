set.seed(123)  # Tekrarlanabilirlik için seed belirleme

# Bağımsız değişkenler
x1 <- rnorm(100, mean = 50, sd = 10)  # Normal dağılımlı bağımsız değişken 1
x2 <- rnorm(100, mean = 30, sd = 5)   # Normal dağılımlı bağımsız değişken 2
x3 <- runif(100, min = 0, max = 1)    # Uniform dağılımlı bağımsız değişken 3

# Bağımlı değişken
y <- 2*x1 + 3*x2 + 0.5*x3 + rnorm(100, mean = 0, sd = 5)  # Bağımlı değişken

# Veri seti oluşturma
veri <- data.frame(x1, x2, x3, y)

# Veri setinin yapısını inceleme
str(veri)

# İlk birkaç gözlemi gösterme
head(veri)

# Özet istatistikler
summary(veri)

# Histogramlar
par(mfrow = c(2, 2))  # 2x2 matris düzeni için grafik penceresi oluştur
hist(veri$x1, main = "x1 Dağılımı", xlab = "x1 Değerleri")
hist(veri$x2, main = "x2 Dağılımı", xlab = "x2 Değerleri")
hist(veri$x3, main = "x3 Dağılımı", xlab = "x3 Değerleri")
hist(veri$y, main = "y Dağılımı", xlab = "y Değerleri")

# Scatter plot
pairs(veri)

#Veri setimiz 100 gözlem ve 4 değişkenden oluşmaktadır.
#x1, x2 ve x3 bağımsız değişkenlerdir, y bağımlı değişkendir.
#Tüm değişkenler sayısal (numeric) türdedir.
#x1 değişkeninin minimum değeri 37.17, maksimum değeri 68.26'dır. Diğer değişkenler için benzer şekilde özet istatistikler bulunmaktadır.
#Histogramlar, değişkenlerin dağılımlarını göstermektedir.
#x1 ve x2 değişkenleri neredeyse normal dağılıma benzer dağılımlar göstermektedir.
#x3 değişkeni uniform bir dağılıma yakın görünmektedir.
#y değişkeni ise normal dağılıma benzer bir dağılım göstermektedir.

# Scatterplot incelendiğinde ; x1 ve x2 değişkenleri arasında pozitif bir ilişki görünmektedir.
#x1 ve x3, x2 ve x3 arasında ise belirgin bir ilişki gözlenmemektedir.
#y değişkeni negatif değerler içermektedir. Bu, oluşturduğumuz bağımlı değişkenin negatif değerler alabileceği anlamına gelebilir.

# Çeyreklikler, minimum ve maksimum değerlerin hesaplanması
Q1 <- quantile(veri$y, 0.25)
Medyan <- median(veri$y)
Q3 <- quantile(veri$y, 0.75)
Minimum <- min(veri$y)
Maksimum <- max(veri$y)

# Eksik değerlerin sayısı
missing_values <- colSums(is.na(veri))
print(missing_values)  #Veri setinde herhangi bir eksik değer bulunmamaktadır.

set.seed(123)  # Tekrarlanabilirlik için seed belirleme
index <- sample(1:nrow(veri), 5)  # Rastgele 5 indeks seçme
veri$x2[index] <- NA  # Seçilen indekslerdeki x2 değerlerini NaN yapma

# x2 değişkenindeki NA değerleri ortalama ile doldurma
ortalama_x2 <- mean(veri$x2, na.rm = TRUE)  # NA olmayan x2 değerlerinin ortalama
veri$x2[is.na(veri$x2)] <- ortalama_x2  # NA değerleri ortalama ile doldurma

# Doldurulan x2 değerlerini yazdırma
print(veri$x2[index])

# Rastgele NA değerler oluşturma
set.seed(123)  # Tekrarlanabilirlik için seed belirleme
index <- sample(1:nrow(veri), 5)  # Rastgele 5 indeks seçme
veri$x3[index] <- NA  # Seçilen indekslerdeki x3 değerlerini NA yapma

# x3 değişkenindeki NA değerleri en yakın değer ile doldurma
library(imputeTS)
veri$x3 <- na.knn(veri$x3, k = 5)  # En yakın değer ile eksik verileri doldurma

# Doldurulan x3 değerlerini yazdırma
print(veri$x3[index])

#Aykırı değerler için kutu grafiği çizdirelim.

# Kutu grafikleri çizme
par(mfrow = c(1, 3))  
boxplot(veri$x1, main = "x1 Kutu Grafiği")
boxplot(veri$x2, main = "x2 Kutu Grafiği")
boxplot(veri$x3, main = "x3 Kutu Grafiği")

# Z-Skoru Yöntemi ile Aykırı Değerleri Belirleme
z_scores <- scale(veri$x1)  # Z-skorlarını hesaplama
outliers_zscore <- abs(z_scores) > 3  # Z-skoru ±3 sınırlarının dışındaki değerleri belirleme

# IQR Yöntemi ile Aykırı Değerleri Belirleme
Q1 <- quantile(veri$x1, 0.25)
Q3 <- quantile(veri$x1, 0.75)
IQR <- Q3 - Q1
lower_bound <- Q1 - 1.5 * IQR  # Alt sınır
upper_bound <- Q3 + 1.5 * IQR  # Üst sınır
outliers_iqr <- veri$x1 < lower_bound | veri$x1 > upper_bound  # Aykırı değerleri belirleme


# Z-Skoru Yöntemi ile Belirlenen Aykırı Değerlerin Sayısı
count_outliers_zscore <- sum(outliers_zscore)
count_outliers_zscore
# Z-Skoru Yöntemi ile Belirlenen Aykırı Değerlerin Değerleri
outliers_values_zscore <- veri$x1[outliers_zscore]
outliers_values_zscore

# IQR Yöntemi ile Belirlenen Aykırı Değerlerin Sayısı
count_outliers_iqr <- sum(outliers_iqr)
count_outliers_iqr
# IQR Yöntemi ile Belirlenen Aykırı Değerlerin Değerleri
outliers_values_iqr <- veri$x1[outliers_iqr]
outliers_values_iqr

# Z-Skoru Yöntemi ile Belirlenen Aykırı Değerlerin Değerleri
print(outliers_values_zscore)

# IQR Yöntemi ile Belirlenen Aykırı Değerlerin Değerleri
print(outliers_values_iqr)

#Z-Skoru yöntemiyle belirlenen aykırı değerlerin değerlerine bakıldığında, bu değerlerin genellikle veri setinin ortalama etrafında oldukça uzakta olduğu görülmektedir. Bu aykırı değerler, genellikle diğer gözlemlerden oldukça farklıdır ve analizinizi etkileyebilir. 
#IQR yöntemiyle belirlenen aykırı değerlerin değerlerine baktığımızda, bu değerlerin genellikle veri setinin alt veya üst sınırı dışında olduğu görülmektedir. Bu aykırı değerler, diğer gözlemlerden önemli ölçüde farklıdır ve analizinizi etkileyebilir.

# Aykırı değerlerle regresyon analizi
model_with_outliers <- lm(y ~ x1 + x2 + x3, data = veri)
summary(model_with_outliers)

# Aykırı değerlerin belirli bir yüzdelik dilimdeki değerlerle değiştirilmesi
veri_cleaned <- veri  # Temizlenmiş veri setini saklama
veri_cleaned$x1[outliers_zscore] <- quantile(veri$x1, c(0.05, 0.95))  # Aykırı değerleri 5. ve 95. yüzdelik dilimdeki değerlerle değiştirme
veri_cleaned$x2[outliers_zscore] <- quantile(veri$x2, c(0.05, 0.95))  # Aykırı değerleri 5. ve 95. yüzdelik dilimdeki değerlerle değiştirme
veri_cleaned$x3[outliers_zscore] <- quantile(veri$x3, c(0.05, 0.95))  # Aykırı değerleri 5. ve 95. yüzdelik dilimdeki değerlerle değiştirme

# Temizlenmiş veri seti ile regresyon analizi
model_without_outliers <- lm(y ~ x1 + x2 + x3, data = veri_cleaned)
summary(model_without_outliers)

summary(model_with_outliers)
summary(model_without_outliers)

#Aykırı değerlerle yapılan regresyon analizi sonuçlarına göre, modelin katsayıları ve hata terimleri bir miktar değişmiştir. Ancak, bu değişiklikler genellikle küçüktür.
#R-kare değeri ve düzeltilmiş R-kare değeri değişmemiştir veya hafifçe artmıştır. Bu, aykırı değerlerin modelin açıklama gücü üzerinde çok büyük bir etkisinin olmadığını gösterir.
#F-statistic ve p-value değerleri, modelin istatistiksel olarak anlamlı olduğunu ve bağımsız değişkenlerin en az birinin bağımlı değişkendeki varyansı açıklamada anlamlı olduğunu gösterir.
#Her iki senaryoda da, bağımsız değişkenlerden x1 ve x2'nin p değerleri oldukça küçüktür, yani bu değişkenlerin modelde istatistiksel olarak anlamlı olduğu söylenebilir. Ancak, x3 değişkeninin p değeri yüksektir, bu da bu değişkenin modelde istatistiksel olarak anlamsız olduğunu gösterir.

# Değişkenler arasındaki korelasyon matrisini hesaplama
correlation_matrix <- cor(veri[, c("x1", "x2", "x3")])
print(correlation_matrix)

#Verilen veri setindeki değişkenler arasında çok düşük ve zayıf ilişkiler vardır. Bu nedenle, bu değişkenler arasında önemli bir ilişki olduğunu söylemek güçtür.

# Paketi yükleme
install.packages("caret")
library(caret)

veri <- iris 

# Veri setini rastgele olarak 0.75 / 0.25 oranında eğitim ve test alt kümelerine bölmek
set.seed(123) 
trainIndex <- createDataPartition(veri$Species, p = .75, 
                                  list = FALSE, 
                                  times = 1)
eğitim <- veri[ trainIndex,]
test  <- veri[-trainIndex,]

# Eğitim alt kümesinin boyutu
dim(eğitim)
# Test alt kümesinin boyutu
dim(test)

#Eğitim alt kümesi, orijinal veri setinin yaklaşık %75'ini oluştururken, test alt kümesi geriye kalan %25'ini oluşturur. Bu, veri setinin büyük bir kısmının eğitim için kullanılacağını, küçük bir kısmının ise test etmek için ayrıldığını gösterir.
#Alt kümelerin boyutları veri setinin boyutuna göre oldukça dengelidir, bu da rastgele bir bölme yapıldığını ve sınıfların (iris türleri) eşit dağıldığını gösterir. 